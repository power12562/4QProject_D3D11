#pragma once
#include <vector>
#include <directxtk/SimpleMath.h>
#include "Physics/PhysXFramework.h"
#include "Physics/PhysicsLayerManager/PhysicsLayerManager.h"
#include "Physics/Struct/RaycastResult.h"
#include "Physics/PhysicsScene/PhysicsScene.h"
#include "Core/TSingleton.h"

using namespace DirectX::SimpleMath;

class PhysicsManager : public TSingleton<PhysicsManager>
{
	using uint = unsigned int;


	static px::PxFilterFlags DefaultPhysicsFilterShader(px::PxFilterObjectAttributes attributes0, px::PxFilterData filterData0, px::PxFilterObjectAttributes attributes1, px::PxFilterData filterData1, px::PxPairFlags& pairFlags, const void* constantBlock, px::PxU32 constantBlockSize);



	px::PxDefaultAllocator px_allocator_callback;
	px::PxDefaultErrorCallback px_error_callback;

	px::PxDefaultCpuDispatcher* px_dispatcher{ nullptr };
	px::PxFoundation* px_foundation{ nullptr };
	px::PxTolerancesScale px_tolerance_scale;
	px::PxPhysics* px_physics{ nullptr };

	// GPU ���� ���� �ʿ�
	px::PxCudaContextManager* px_cuda_manager{ nullptr };

	px::PxPvd* px_pvd{ nullptr };


	// ���� �浹 ���͸� ���̾�
	PhysicsLayerManager* layer_manager{ nullptr };

	PhysicsScene* physics_scene{nullptr};
	static px::PxSceneDesc* default_scene_desc;
	const bool use_gpu_acceleration{ false };

public:
	PhysicsManager(const PhysicsManager&) = delete;
	PhysicsManager& operator=(const PhysicsManager&) = delete;
	PhysicsManager();
	~PhysicsManager();

	PhysicsScene* GetPhysicsScene() { return physics_scene;}
	void ClearPhysicsScene();

	px::PxDefaultCpuDispatcher* GetCpuDispatcher();
	px::PxFoundation* GetFoundation();
	px::PxTolerancesScale* GetToleranceScale();
	px::PxPhysics* GetPhysics();
	px::PxPvd* GetPVD();
	void ConnectSceneWithPVD(px::PxScene* scene);

	PhysicsLayerManager& GetPhysicsLayerManager() { return *layer_manager; }


	// �浹 �� �̺�Ʈ�� �߻��� ���̾� �� ����
public:
	void SetPhysicsLayer(class GameObject* object, uint physics_layer_slot);
	void SetPhysicsLayer(class Collider* collider, uint physics_layer_slot);


	void OnAddRigidbody(class GameObject* object, class Rigidbody* rb);
	void OnAddCollider(class GameObject* object, class Collider* collider);


	// Queries
public:
	RaycastResult Raycast(Vector3 origin, Vector3 direction, float length, bool return_on_first_contact, uint MAX_HIT = 256);
};
