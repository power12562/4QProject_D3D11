#pragma once

struct CollisionInfo
{
	class Object* opponent{ nullptr };
	class Collider* my_collider{ nullptr };
	class Collider* opponents_collider{ nullptr };
};