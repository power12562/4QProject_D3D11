#pragma once

enum class PhysicsMaterialCombineMode
{
	Average,
	Min,
	Multiply,
	Max
};