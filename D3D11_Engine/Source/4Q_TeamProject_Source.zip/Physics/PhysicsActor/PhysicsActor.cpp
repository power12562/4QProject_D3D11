#include "Physics/PhysicsActor/PhysicsActor.h"
#include "Physics/PhysicsManager.h"
#include "GameObject/Base/GameObject.h"


PhysicsActor::PhysicsActor(GameObject* bind_object, px::PxScene* scene, Vector3 init_pos, Quaternion init_rot, PhysicsActorType actor_type)
{
	px::PxPhysics* physics = Core::GetInstance().GetPhysicsManager().GetPhysics();

	px::PxTransform transform(init_pos, init_rot.ToPxQuat());

	this->actor_type = actor_type;
	if (actor_type == PhysicsActorType::StaticBody)
	{
		actor = physics->createRigidStatic(transform);
	}
	else if (actor_type == PhysicsActorType::DynamicBody)
	{
		actor = physics->createRigidDynamic(transform);
	}
	else if (actor_type == PhysicsActorType::KinematicBody)
	{
		actor = physics->createRigidDynamic(transform);
		SetIsKinematic(true);
	}

	scene->addActor(*actor);
	SetSleepThreshold(sleep_threshold);

	actor->userData = static_cast<void*>(bind_object);
}

PhysicsActor::~PhysicsActor()
{
	// ������ PxScene::releaseActor()�� ȣ������ �ʾƵ� �˾Ƽ� ���ŵ�
	// PxActor�� PxShape�� ��Ⱑ �ٸ��� ȥ������ ����.
	if (actor != nullptr) actor->release();
}




void PhysicsActor::SetFreezeMoveX(bool freeze)
{
	if (actor_type == PhysicsActorType::StaticBody) return;

	freeze_move_x = freeze;
	static_cast<px::PxRigidDynamic*>(actor)->setRigidDynamicLockFlag(px::PxRigidDynamicLockFlag::eLOCK_LINEAR_X, freeze);
}

void PhysicsActor::SetFreezeMoveY(bool freeze)
{
	if (actor_type == PhysicsActorType::StaticBody) return;

	freeze_move_y = freeze;
	static_cast<px::PxRigidDynamic*>(actor)->setRigidDynamicLockFlag(px::PxRigidDynamicLockFlag::eLOCK_LINEAR_Y, freeze);
}

void PhysicsActor::SetFreezeMoveZ(bool freeze)
{
	if (actor_type == PhysicsActorType::StaticBody) return;

	freeze_move_z = freeze;
	static_cast<px::PxRigidDynamic*>(actor)->setRigidDynamicLockFlag(px::PxRigidDynamicLockFlag::eLOCK_LINEAR_Z, freeze);
}

void PhysicsActor::SetFreezeRotateX(bool freeze)
{
	if (actor_type == PhysicsActorType::StaticBody) return;

	freeze_rotate_x = freeze;
	static_cast<px::PxRigidDynamic*>(actor)->setRigidDynamicLockFlag(px::PxRigidDynamicLockFlag::eLOCK_ANGULAR_X, freeze);
}

void PhysicsActor::SetFreezeRotateY(bool freeze)
{
	if (actor_type == PhysicsActorType::StaticBody) return;

	freeze_rotate_y = freeze;
	static_cast<px::PxRigidDynamic*>(actor)->setRigidDynamicLockFlag(px::PxRigidDynamicLockFlag::eLOCK_ANGULAR_Y, freeze);
}

void PhysicsActor::SetFreezeRotateZ(bool freeze)
{
	if (actor_type == PhysicsActorType::StaticBody) return;

	freeze_rotate_z = freeze;
	static_cast<px::PxRigidDynamic*>(actor)->setRigidDynamicLockFlag(px::PxRigidDynamicLockFlag::eLOCK_ANGULAR_Z, freeze);
}

void PhysicsActor::SetUseGravity(bool use_gravity)
{
	if (actor_type == PhysicsActorType::StaticBody) return;

	this->use_gravity = use_gravity;
	actor->setActorFlag(px::PxActorFlag::eDISABLE_GRAVITY, !use_gravity);
}

void PhysicsActor::SetSendEventOnSleepAndWake(bool send_event)
{
	send_event_on_sleep_and_wake = send_event;
	actor->setActorFlag(px::PxActorFlag::eSEND_SLEEP_NOTIFIES, send_event);
}

void PhysicsActor::SetEnableSimulation(bool enable_simulation)
{
	this->enable_simulation = enable_simulation;
	actor->setActorFlag(px::PxActorFlag::eDISABLE_SIMULATION, !enable_simulation);
}
void PhysicsActor::SetIsKinematic(bool is_kinematic)
{
	if (actor_type == PhysicsActorType::StaticBody) return;

	this->is_kinematic = is_kinematic;
	px::PxRigidDynamic* rb = static_cast<px::PxRigidDynamic*>(actor);
	rb->setRigidBodyFlag(px::PxRigidBodyFlag::eKINEMATIC, is_kinematic);
}
void PhysicsActor::SetMass(float mass)
{
	if (actor_type == PhysicsActorType::StaticBody) return;

	px::PxRigidDynamic* rb = static_cast<px::PxRigidDynamic*>(actor);
	rb->setMass(mass);
}
void PhysicsActor::SetDrag(float drag)
{
	if (actor_type == PhysicsActorType::StaticBody) return;

	px::PxRigidDynamic* rb = static_cast<px::PxRigidDynamic*>(actor);
	rb->setLinearDamping(drag);
}
void PhysicsActor::SetAngularDrag(float angular_drag)
{
	if (actor_type == PhysicsActorType::StaticBody) return;

	px::PxRigidDynamic* rb = static_cast<px::PxRigidDynamic*>(actor);
	rb->setAngularDamping(drag);
}
//void PhysicsActor::SetAutomaticCenterOfMass(bool automatic_center_of_mass)
//{
//	if (actor_type == PhysicsActorType::StaticBody) return;
//
//	px::PxRigidDynamic* rb = static_cast<px::PxRigidDynamic*>(actor);
//	rb->setRigidBodyFlag(px::PxRigidBodyFlag::eKINEMATIC, is_kinematic);
//}
//void PhysicsActor::SetAutomaticTensor(bool automatic_tensor)
//{
//	if (actor_type == PhysicsActorType::StaticBody) return;
//
//	px::PxRigidDynamic* rb = static_cast<px::PxRigidDynamic*>(actor);
//	rb->setRigidBodyFlag(px::PxRigidBodyFlag::eKINEMATIC, is_kinematic);
//}




void PhysicsActor::SetCollisionDetectionMode(CollisionDetectionMode detection_mode)
{
	if (actor_type == PhysicsActorType::StaticBody) return;
	px::PxRigidDynamic* rb = static_cast<px::PxRigidDynamic*>(actor);

	collision_detection_mode = detection_mode;
	switch (detection_mode)
	{
	case CollisionDetectionMode::Discrete:
		rb->setRigidBodyFlag(px::PxRigidBodyFlag::eENABLE_CCD, false);
		break;
	case CollisionDetectionMode::Continuous:
		rb->setRigidBodyFlag(px::PxRigidBodyFlag::eENABLE_CCD, true);
		break;
	case CollisionDetectionMode::ContinuousDynamic:
		rb->setRigidBodyFlag(px::PxRigidBodyFlag::eENABLE_CCD, true);
		rb->setRigidBodyFlag(px::PxRigidBodyFlag::eENABLE_CCD_FRICTION, true);
		break;
	}
}

void PhysicsActor::AddForce(Vector3 force, ForceMode force_mode)
{
	if (actor_type == PhysicsActorType::StaticBody) return;

	px::PxRigidDynamic* rb = static_cast<px::PxRigidDynamic*>(actor);

	switch (force_mode)
	{
	case ForceMode::Force:
		rb->addForce(force, px::PxForceMode::eFORCE);
		break;
	case ForceMode::Impulse:
		rb->addForce(force, px::PxForceMode::eIMPULSE);
		break;
	case ForceMode::Acceleration:
		rb->addForce(force, px::PxForceMode::eACCELERATION);
		break;
	case ForceMode::VelocityChange:
		rb->addForce(force, px::PxForceMode::eVELOCITY_CHANGE);
		break;
	}
}

void PhysicsActor::AddTorque(Vector3 force, ForceMode force_mode)
{
	if (actor_type == PhysicsActorType::StaticBody) return;

	px::PxRigidDynamic* rb = static_cast<px::PxRigidDynamic*>(actor);

	switch (force_mode)
	{
	case ForceMode::Force:
		rb->addTorque(force, px::PxForceMode::eFORCE);
		break;
	case ForceMode::Impulse:
		rb->addTorque(force, px::PxForceMode::eIMPULSE);
		break;
	case ForceMode::Acceleration:
		rb->addTorque(force, px::PxForceMode::eACCELERATION);
		break;
	case ForceMode::VelocityChange:
		rb->addTorque(force, px::PxForceMode::eVELOCITY_CHANGE);
		break;
	}
}

void PhysicsActor::SetVelocity(Vector3 velocity)
{
	if (actor_type == PhysicsActorType::StaticBody) return;

	px::PxRigidDynamic* rb = static_cast<px::PxRigidDynamic*>(actor);
	rb->setLinearVelocity(velocity);
}

void PhysicsActor::SetAngularVelocity(Vector3 velocity)
{
	if (actor_type == PhysicsActorType::StaticBody) return;

	px::PxRigidDynamic* rb = static_cast<px::PxRigidDynamic*>(actor);
	rb->setAngularVelocity(velocity);
}

void PhysicsActor::SetSleepThreshold(float threshold)
{
	if (actor_type == PhysicsActorType::StaticBody) return;

	sleep_threshold = threshold;
	px::PxRigidDynamic* rb = static_cast<px::PxRigidDynamic*>(actor);
	rb->setSleepThreshold(threshold);
}

void PhysicsActor::UpdateTransform(Transform* transform)
{
	const px::PxTransform& px_transform = actor->getGlobalPose();

	Vector3 position{ px_transform.p };
	Quaternion rotation{ px_transform.q.x, px_transform.q.y, px_transform.q.z, px_transform.q.w };

	Vector3 parent_position = transform->GetParent()->GetPosition();
	Vector3 relative_position = position - parent_position;

	Quaternion parent_rotation = transform->GetParent()->GetRotation();
	Quaternion relative_rotation = parent_rotation.InverseQuaternion() * rotation;

	transform->SetPosition(relative_position);
	transform->SetRotation(relative_rotation);
}