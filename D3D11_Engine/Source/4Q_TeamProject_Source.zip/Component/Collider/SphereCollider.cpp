#include "Component/Collider/SphereCollider.h"


SphereCollider::~SphereCollider()
{
	DetachShapeToActor();
}

void SphereCollider::SetSize(float radius)
{
	this->radius = radius;
	UpdateShape();
	AttachShapeToActor();
}

void SphereCollider::SetSizeFollowingMesh()
{
	MeshRenderer* mRenderer = GetOwner()->GetComponent<MeshRenderer>();
	if (mRenderer == nullptr || mRenderer->mesh == nullptr)
	{
		UpdateShape();
		return;
	}

	Mesh* mesh = mRenderer->mesh;
	BoundingBox& bb = mesh->GetBoundingBox();

	radius = std::max<float>({ bb.Extents.x, bb.Extents.y, bb.Extents.z });
	UpdateShape();
}

void SphereCollider::DrawBounds(Color color)
{
	BoundingSphere bs;
	bs.Center = { 0, 0, 0 };
	bs.Radius = radius;
	bs.Transform(bs, GetOwner()->transform->GetWorldTransformMatrix());

	Gizmo::DrawBounds(bs, color);
}

void SphereCollider::AttachShapeToActor()
{
	if (shape == nullptr)
	{
		Debug::LogError("PxShape not found.");
		return;
	}

	PhysicsActor* actor = GetOwner()->GetPhysicsActor();
	if (actor == nullptr)
	{
		Debug::LogError("PxActor not found.");
		return;
	}

	actor->GetActor()->attachShape(*shape);
}

void SphereCollider::UpdateShape()
{
	if (shape != nullptr)
	{
		DetachShapeToActor();
		shape->release();
	}

	px::PxPhysics* physics = Core::GetInstance().GetPhysicsManager().GetPhysics();

	Vector3 scale = GetOwner()->transform->GetScale();
	px::PxSphereGeometry geometry{ radius * std::max<float>({scale.x, scale.y, scale.z}) };

	PhysicsMaterial* pm = GetPhysicsMaterial();
	if (pm == nullptr)
	{
		pm = Core::GetInstance().GetResourceManager().GetDefaultPhysicsMaterial();
	}
	shape = physics->createShape(geometry, *pm->GetPxMaterial(), true);
	shape->userData = static_cast<void*>(this);
}

void SphereCollider::DetachShapeToActor()
{
	if (shape == nullptr)
	{
		Debug::LogError("PxShape not found.");
		return;
	}

	PhysicsActor* actor = GetOwner()->GetPhysicsActor();
	if (actor == nullptr)
	{
		Debug::LogError("PxActor not found.");
		return;
	}

	actor->GetActor()->detachShape(*shape);
}

void SphereCollider::SetIsTrigger(bool is_trigger)
{
	this->is_trigger = is_trigger;
	if (shape == nullptr)
	{
		Debug::LogError("PxShape not found.");
		return;
	}

	shape->setFlag(px::PxShapeFlag::eSIMULATION_SHAPE, !is_trigger);
	shape->setFlag(px::PxShapeFlag::eTRIGGER_SHAPE, is_trigger);
}