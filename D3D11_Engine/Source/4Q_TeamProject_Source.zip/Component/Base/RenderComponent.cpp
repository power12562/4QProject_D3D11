#include "RenderComponent.h"

RenderComponent::RenderComponent()
{
	
}

RenderComponent::~RenderComponent()
{
	
}
